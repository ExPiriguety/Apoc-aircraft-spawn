# Apocalipse Aircraft Spawn 1.0.1 (código-fonte reconstruído)

Reconstruído a partir do .jar 1.0.0. Copie a pasta `src/` para dentro do seu projeto
Forge 1.20.1 (mappings oficiais) e compile como de costume.

## O que mudou

1. **Bug corrigido: uma única tentativa por estrutura.**
   O mod agora salva no mundo (`data/apoc_aircraft_spawn_attempts.dat`) a chave
   `id_da_estrutura@chunkX,chunkZ`. Quem já tentou uma vez nunca tenta de novo,
   tendo spawnado ou não. Outras vilas do mesmo tipo têm outra chave e sorteiam normalmente.
2. **Pesos nas estruturas específicas** (`aircraftPool`), veja abaixo.
3. Comando novo `/apocaircraft reset` (apaga o registro, útil para testar).
4. Config malformado (JSON quebrado) agora cai no padrão em vez de dar exceção.

## Config nova nas estruturas específicas

```json
"specific": [
  {
    "structure": "algummod:aeroporto",
    "chance": 1.0,
    "aircraftPool": [
      { "id": "immersive_aircraft:biplane",     "weight": 40 },
      { "id": "immersive_aircraft:gyrodyne",    "weight": 30 },
      { "id": "immersive_aircraft:airship",     "weight": 15 },
      { "id": "immersive_aircraft:warship",     "weight": 10 },
      { "id": "immersive_aircraft:quadrocopter","weight": 5 }
    ]
  },
  { "structure": "algummod:hospital", "aircraft": "immersive_aircraft:gyrodyne", "chance": 0.5 }
]
```

- `chance` é sorteado primeiro (1.0 = 100%); passou, sorteia 1 aeronave da pool pelo peso.
- O formato antigo (`"aircraft": "..."`) continua funcionando. Se tiver `aircraftPool`, ela vence.
