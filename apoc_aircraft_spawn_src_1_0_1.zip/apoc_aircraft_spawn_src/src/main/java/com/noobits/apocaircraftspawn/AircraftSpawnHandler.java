package com.noobits.apocaircraftspawn;

import com.noobits.apocaircraftspawn.config.AircraftEntry;
import com.noobits.apocaircraftspawn.config.GlobalConfig;
import com.noobits.apocaircraftspawn.config.RootConfig;
import com.noobits.apocaircraftspawn.config.SpecificEntry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.Map;
import java.util.Random;

public class AircraftSpawnHandler {
    private static final Random RANDOM = new Random();
    private static final int MAX_POSITION_ATTEMPTS = 12;

    @SubscribeEvent
    public void onChunkLoad(ChunkEvent.Load event) {
        LevelAccessor accessor = event.getLevel();
        if (!(accessor instanceof ServerLevel level)) return;

        ChunkAccess chunk = event.getChunk();
        Map<Structure, StructureStart> starts = chunk.getAllStarts();
        if (starts.isEmpty()) return;

        ChunkPos chunkPos = chunk.getPos();
        Registry<Structure> registry = level.registryAccess().registryOrThrow(Registries.STRUCTURE);

        for (Map.Entry<Structure, StructureStart> entry : starts.entrySet()) {
            StructureStart start = entry.getValue();
            if (start == null || !start.isValid()) continue;
            // so processa no chunk de origem da estrutura
            if (!start.getChunkPos().equals(chunkPos)) continue;

            ResourceLocation id = registry.getKey(entry.getKey());
            if (id == null) continue;

            processStructure(level, id, start);
        }
    }

    private void processStructure(ServerLevel level, ResourceLocation id, StructureStart start) {
        RootConfig cfg = ConfigManager.get();
        String structureId = id.toString();

        boolean hasSpecific = false;
        if (cfg.specific != null) {
            for (SpecificEntry s : cfg.specific) {
                if (s.structure != null && s.structure.equals(structureId)) {
                    hasSpecific = true;
                    break;
                }
            }
        }
        boolean inGlobal = cfg.global != null
                && cfg.global.structures != null
                && cfg.global.structures.contains(structureId);

        // estrutura que nao esta no config nao gasta registro nenhum
        if (!hasSpecific && !inGlobal) return;

        // ---- CORRECAO DO BUG ----
        // Cada estrutura (id + chunk de origem) so pode ter UMA tentativa na vida do mundo.
        // O registro e salvo no mundo, entao vale mesmo depois de sair e voltar na vila.
        // Outras estruturas do mesmo tipo (outras vilas do deserto) tem chave diferente
        // e continuam podendo sortear normalmente.
        ChunkPos origin = start.getChunkPos();
        String key = structureId + "@" + origin.x + "," + origin.z;
        if (!SpawnRecordData.get(level).markAttempted(key)) {
            if (cfg.debug) {
                broadcastDebug(level, "'" + structureId + "' (chunk " + origin.x + "," + origin.z
                        + ") ja teve a tentativa dela, ignorando.");
            }
            return;
        }

        // ---- configs especificas (cada entrada faz o proprio sorteio de chance) ----
        if (cfg.specific != null) {
            for (SpecificEntry s : cfg.specific) {
                if (s.structure == null || !s.structure.equals(structureId)) continue;

                if (RANDOM.nextDouble() < s.chance) {
                    String aircraftId;
                    if (s.aircraftPool != null && !s.aircraftPool.isEmpty()) {
                        aircraftId = pickWeightedAircraft(s.aircraftPool);
                        if (aircraftId == null) {
                            if (cfg.debug) {
                                broadcastDebug(level, "'" + structureId + "' passou na chance, mas a aircraftPool tem soma de pesos 0/invalida.");
                            }
                            continue;
                        }
                    } else {
                        aircraftId = s.aircraft;
                    }
                    trySpawn(level, id, start, aircraftId);
                } else if (cfg.debug) {
                    String what = (s.aircraftPool != null && !s.aircraftPool.isEmpty())
                            ? "uma das " + s.aircraftPool.size() + " aeronaves da pool"
                            : String.valueOf(s.aircraft);
                    broadcastDebug(level, "'" + structureId + "' nao spawnou (chance " + toPercent(s.chance)
                            + "%, aeronave seria " + what + ")");
                }
            }
        }

        // ---- config global ----
        if (inGlobal) {
            GlobalConfig g = cfg.global;
            if (RANDOM.nextDouble() < g.chance) {
                String aircraftId = pickWeightedAircraft(g.aircraft);
                if (aircraftId != null) {
                    trySpawn(level, id, start, aircraftId);
                } else if (cfg.debug) {
                    broadcastDebug(level, "'" + structureId + "' passou na chance, mas a lista de aeronaves esta vazia/invalida no config.");
                }
            } else if (cfg.debug) {
                broadcastDebug(level, "'" + structureId + "' nao spawnou (chance global " + toPercent(g.chance) + "%)");
            }
        }
    }

    private void trySpawn(ServerLevel level, ResourceLocation structureId, StructureStart start, String aircraftId) {
        if (aircraftId == null || aircraftId.isBlank()) {
            debugFail(level, structureId, aircraftId, "ID de aeronave vazio no config");
            return;
        }
        ResourceLocation entityId = ResourceLocation.tryParse(aircraftId);
        if (entityId == null) {
            debugFail(level, structureId, aircraftId, "ID de aeronave invalido (formato errado)");
            return;
        }
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(entityId);
        if (type == null) {
            debugFail(level, structureId, aircraftId, "aeronave nao encontrada no registro (mod nao instalado ou ID errado)");
            return;
        }
        BlockPos spawnPos = findSafePosition(level, start);
        if (spawnPos == null) {
            debugFail(level, structureId, aircraftId, "nao achei uma posicao livre pra spawnar depois de " + MAX_POSITION_ATTEMPTS + " tentativas");
            return;
        }
        Entity entity = type.create(level);
        if (entity == null) {
            debugFail(level, structureId, aircraftId, "falha ao instanciar a entidade");
            return;
        }
        entity.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D, RANDOM.nextFloat() * 360.0F, 0.0F);
        level.addFreshEntity(entity);

        if (ConfigManager.get().debug) {
            broadcastDebug(level, "Spawnou '" + aircraftId + "' em '" + structureId + "' nas coordenadas "
                    + spawnPos.getX() + " " + spawnPos.getY() + " " + spawnPos.getZ());
        }
    }

    private BlockPos findSafePosition(ServerLevel level, StructureStart start) {
        BoundingBox box = start.getBoundingBox();
        for (int i = 0; i < MAX_POSITION_ATTEMPTS; i++) {
            int x = box.minX() + RANDOM.nextInt(Math.max(1, box.maxX() - box.minX() + 1));
            int z = box.minZ() + RANDOM.nextInt(Math.max(1, box.maxZ() - box.minZ() + 1));
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (hasClearance(level, pos)) {
                return pos;
            }
        }
        return null;
    }

    private boolean hasClearance(ServerLevel level, BlockPos pos) {
        for (int i = 0; i < 3; i++) {
            BlockPos p = pos.above(i);
            if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /** Sorteia uma aeronave pelo peso. Retorna null se a lista for vazia ou a soma dos pesos for 0. */
    private String pickWeightedAircraft(List<AircraftEntry> list) {
        if (list == null || list.isEmpty()) return null;
        int total = list.stream().mapToInt(e -> Math.max(0, e.weight)).sum();
        if (total <= 0) return null;
        int roll = RANDOM.nextInt(total);
        int acc = 0;
        for (AircraftEntry e : list) {
            acc += Math.max(0, e.weight);
            if (roll < acc) {
                return e.id;
            }
        }
        return list.get(list.size() - 1).id;
    }

    private void debugFail(ServerLevel level, ResourceLocation structureId, String aircraftId, String reason) {
        if (ConfigManager.get().debug) {
            broadcastDebug(level, "Falha ao spawnar '" + aircraftId + "' em '" + structureId + "': " + reason);
        }
        ApocAircraftSpawn.LOGGER.warn("[{}] Falha ao spawnar '{}' em '{}': {}",
                ApocAircraftSpawn.MODID, aircraftId, structureId, reason);
    }

    private void broadcastDebug(ServerLevel level, String message) {
        level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("[ApocAircraftSpawn] " + message), false);
    }

    private static String toPercent(double chance) {
        return String.valueOf(Math.round(chance * 100.0D));
    }
}
