package com.noobits.apocaircraftspawn;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ReloadCommand {

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("apocaircraft")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("reload")
                        .executes(ctx -> {
                            ConfigManager.load();
                            ctx.getSource().sendSuccess(
                                    () -> Component.literal("[ApocAircraftSpawn] Config recarregado. debug=" + ConfigManager.get().debug),
                                    true);
                            return 1;
                        }))
                // NOVO: apaga o registro de "estruturas ja tentadas" (util pra testar com o debug)
                .then(Commands.literal("reset")
                        .executes(ctx -> {
                            int total = 0;
                            for (ServerLevel level : ctx.getSource().getServer().getAllLevels()) {
                                total += SpawnRecordData.get(level).clear();
                            }
                            final int removed = total;
                            ctx.getSource().sendSuccess(
                                    () -> Component.literal("[ApocAircraftSpawn] Registro de tentativas apagado (" + removed + " estruturas)."),
                                    true);
                            return 1;
                        })));
    }
}
