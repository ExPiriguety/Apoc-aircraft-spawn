package com.noobits.apocaircraftspawn.config;

import java.util.List;

public class SpecificEntry {
    public String structure;

    /** Formato antigo: uma unica aeronave fixa. Continua funcionando. */
    public String aircraft;

    /**
     * Formato novo: lista de aeronaves com peso. Se existir e nao estiver vazia,
     * tem prioridade sobre "aircraft" e uma das aeronaves e sorteada por peso.
     */
    public List<AircraftEntry> aircraftPool;

    public double chance;

    public SpecificEntry() {
    }

    public SpecificEntry(String structure, String aircraft, double chance) {
        this.structure = structure;
        this.aircraft = aircraft;
        this.chance = chance;
    }

    public SpecificEntry(String structure, List<AircraftEntry> aircraftPool, double chance) {
        this.structure = structure;
        this.aircraftPool = aircraftPool;
        this.chance = chance;
    }
}
