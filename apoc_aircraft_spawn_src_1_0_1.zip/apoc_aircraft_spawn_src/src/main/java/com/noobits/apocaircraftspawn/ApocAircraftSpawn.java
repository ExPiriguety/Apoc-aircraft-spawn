package com.noobits.apocaircraftspawn;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod(ApocAircraftSpawn.MODID)
public class ApocAircraftSpawn {
    public static final String MODID = "apoc_aircraft_spawn";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ApocAircraftSpawn() {
        MinecraftForge.EVENT_BUS.register(new AircraftSpawnHandler());
        MinecraftForge.EVENT_BUS.register(new ReloadCommand());
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        ConfigManager.load();
        LOGGER.info("[{}] Config carregado. debug={}", MODID, ConfigManager.get().debug);
    }
}
