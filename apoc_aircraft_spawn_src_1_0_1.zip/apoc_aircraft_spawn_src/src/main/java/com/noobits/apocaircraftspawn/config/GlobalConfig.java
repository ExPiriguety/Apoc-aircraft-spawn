package com.noobits.apocaircraftspawn.config;

import java.util.List;

public class GlobalConfig {
    public double chance;
    public List<String> structures;
    public List<AircraftEntry> aircraft;
}
