package com.noobits.apocaircraftspawn.config;

import java.util.List;

public class RootConfig {
    public boolean debug = false;
    public GlobalConfig global;
    public List<SpecificEntry> specific;
}
