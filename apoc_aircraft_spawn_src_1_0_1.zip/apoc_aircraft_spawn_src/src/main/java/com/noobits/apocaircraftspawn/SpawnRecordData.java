package com.noobits.apocaircraftspawn;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashSet;
import java.util.Set;

/**
 * Guarda, por dimensao, quais estruturas (id + chunk de origem) ja tiveram a
 * sua UNICA tentativa de spawn. Fica salvo no mundo (pasta data/), entao
 * sobrevive a descarregar chunks, sair do jogo e reiniciar o servidor.
 */
public class SpawnRecordData extends SavedData {
    private static final String NAME = "apoc_aircraft_spawn_attempts";
    private static final String TAG_KEY = "attempted";

    private final Set<String> attempted = new HashSet<>();

    public static SpawnRecordData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(SpawnRecordData::load, SpawnRecordData::new, NAME);
    }

    public static SpawnRecordData load(CompoundTag tag) {
        SpawnRecordData data = new SpawnRecordData();
        ListTag list = tag.getList(TAG_KEY, Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            data.attempted.add(list.getString(i));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (String key : attempted) {
            list.add(StringTag.valueOf(key));
        }
        tag.put(TAG_KEY, list);
        return tag;
    }

    /** @return true se esta e a primeira tentativa (registra); false se ja havia tentado antes. */
    public boolean markAttempted(String key) {
        boolean added = attempted.add(key);
        if (added) {
            setDirty();
        }
        return added;
    }

    /** Apaga todos os registros desta dimensao e devolve quantos eram. */
    public int clear() {
        int n = attempted.size();
        if (n > 0) {
            attempted.clear();
            setDirty();
        }
        return n;
    }
}
