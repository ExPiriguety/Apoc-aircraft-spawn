package com.noobits.apocaircraftspawn;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.noobits.apocaircraftspawn.config.AircraftEntry;
import com.noobits.apocaircraftspawn.config.GlobalConfig;
import com.noobits.apocaircraftspawn.config.RootConfig;
import com.noobits.apocaircraftspawn.config.SpecificEntry;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String FILE_NAME = "apoc_aircraft_spawn.json";
    private static RootConfig current = defaultConfig();

    public static RootConfig get() {
        return current;
    }

    public static Path getConfigPath() {
        return FMLPaths.CONFIGDIR.get().resolve(FILE_NAME);
    }

    public static void load() {
        Path path = getConfigPath();
        try {
            if (!Files.exists(path)) {
                current = defaultConfig();
                save(current);
                ApocAircraftSpawn.LOGGER.info("[{}] Config padrao criado em {}", ApocAircraftSpawn.MODID, path);
                return;
            }
            String json = Files.readString(path, StandardCharsets.UTF_8);
            RootConfig cfg = GSON.fromJson(json, RootConfig.class);
            if (cfg == null) {
                ApocAircraftSpawn.LOGGER.warn("[{}] Config vazio/invalido, usando valores padrao.", ApocAircraftSpawn.MODID);
                cfg = defaultConfig();
            }
            if (cfg.global == null) cfg.global = defaultConfig().global;
            if (cfg.global.structures == null) cfg.global.structures = Collections.emptyList();
            if (cfg.global.aircraft == null) cfg.global.aircraft = Collections.emptyList();
            if (cfg.specific == null) cfg.specific = Collections.emptyList();
            current = cfg;
        } catch (IOException | JsonParseException e) {
            ApocAircraftSpawn.LOGGER.error("[{}] Erro ao ler o config, usando valores padrao em memoria.", ApocAircraftSpawn.MODID, e);
            current = defaultConfig();
        }
    }

    private static void save(RootConfig cfg) throws IOException {
        Path path = getConfigPath();
        Files.createDirectories(path.getParent());
        Files.writeString(path, GSON.toJson(cfg), StandardCharsets.UTF_8);
    }

    private static RootConfig defaultConfig() {
        RootConfig cfg = new RootConfig();
        cfg.debug = false;

        GlobalConfig g = new GlobalConfig();
        g.chance = 0.15;
        g.structures = Arrays.asList(
                "minecraft:village_plains",
                "minecraft:village_savanna",
                "minecraft:village_desert",
                "minecraft:village_taiga",
                "minecraft:village_snowy",
                "minecraft:pillager_outpost",
                "minecraft:desert_pyramid");
        g.aircraft = Arrays.asList(
                new AircraftEntry("immersive_aircraft:biplane", 30),
                new AircraftEntry("immersive_aircraft:airship", 20),
                new AircraftEntry("immersive_aircraft:cargo_airship", 15),
                new AircraftEntry("immersive_aircraft:gyrodyne", 15),
                new AircraftEntry("immersive_aircraft:quadrocopter", 10),
                new AircraftEntry("immersive_aircraft:warship", 5),
                new AircraftEntry("immersive_aircraft:bamboo_hopper", 5));
        cfg.global = g;

        cfg.specific = Arrays.asList(new SpecificEntry(
                "algummod:hospital",
                Arrays.asList(
                        new AircraftEntry("immersive_aircraft:gyrodyne", 70),
                        new AircraftEntry("immersive_aircraft:quadrocopter", 30)),
                0.5));
        return cfg;
    }
}
