package com.noobits.apocaircraftspawn.config;

public class AircraftEntry {
    public String id;
    public int weight;

    public AircraftEntry() {
    }

    public AircraftEntry(String id, int weight) {
        this.id = id;
        this.weight = weight;
    }
}
